﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBO_PROJECT_B3.model
{
    internal class M_Pengguna
    {
        public int id {  get; set; }
        public string nama_pengguna { get; set; }
        public string telp_pengguna { get; set;}
        public string email_pengguna { get; set;}
        public string  username {  get; set; }
        public string password { get; set;}

    }
}
