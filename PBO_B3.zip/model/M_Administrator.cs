﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBO_PROJECT_B3.model
{
    internal class M_Administrator
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string username_admin { get; set; }
        [Required]
        public string pass_admin { get; set; }
       
    }
}
