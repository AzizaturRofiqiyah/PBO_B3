﻿using PBO_PROJECT_B3.core;
using PBO_PROJECT_B3.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PBO_PROJECT_B3.view
{
    public partial class V_Forget : Form
    {
        public V_Forget()
        {
            InitializeComponent();
        }

        private void close2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            V_Login v_login = new V_Login();

            v_login.Show();
            this.Hide();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            string usernameLama = tbreset_UsernameLama.Text;
            string usernameBaru = tbreset_UsernameBaru.Text;
            string passwordBaru = tbreset_Password.Text;

            if (string.IsNullOrWhiteSpace(usernameLama) || string.IsNullOrWhiteSpace(usernameBaru) || string.IsNullOrWhiteSpace(passwordBaru))
            {
                MessageBox.Show("Harap isi semua kolom.");
                return;
            }

            try
            {
                // Periksa apakah username lama ada di database
                DataTable dt = C_admin.loginadminByUsername(usernameLama); // Password lama tidak digunakan di reset
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Username lama tidak ditemukan.");
                    return;
                }

                // Ambil ID dari user yang ingin diperbarui
                int id = Convert.ToInt32(dt.Rows[0]["id"]);

                // Buat objek untuk update
                M_Administrator editAdmin = new M_Administrator
                {
                    id = id,
                    username_admin = usernameBaru,
                    pass_admin = passwordBaru // Password harus dienkripsi untuk keamanan
                };

                // Update data di database
                C_admin.update(editAdmin);

                // Beri notifikasi
                MessageBox.Show("Username dan password berhasil diperbarui.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Terjadi kesalahan: {ex.Message}");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
