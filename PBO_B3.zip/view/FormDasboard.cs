﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PBO_PROJECT_B3.view
{
    public partial class FormDasboard : Form
    {
        public FormDasboard()
        {
            InitializeComponent();
        }

        private void FormDasboard_Load(object sender, EventArgs e)
        {

        }
    }
}
