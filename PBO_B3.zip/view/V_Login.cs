﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;
using PBO_PROJECT_B3.context;
using PBO_PROJECT_B3.core;

namespace PBO_PROJECT_B3.view
{
    public partial class V_Login : Form
    {
        public V_Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            string input_pengguna = tbLogin_username.Text.Trim();
            string pass_pengguna = tbLogin_Password.Text.Trim();

            if (string.IsNullOrWhiteSpace(input_pengguna) || string.IsNullOrWhiteSpace(pass_pengguna))
            {
                MessageBox.Show("Masukkan username dan password.");
                return;
            }
            else
            {
                // Panggil metode loginadmin untuk mencocokkan username dan password
                DataTable dt = C_admin.loginadmin(input_pengguna, pass_pengguna);

                if (dt.Rows.Count > 0)
                {
                    // Login berhasil
                    int Iduser = Convert.ToInt32(dt.Rows[0]["id"]); // Ambil id dari database
                    string username = dt.Rows[0]["username_admin"].ToString(); // Ambil username

                    // Update TextBox jika diperlukan
                    this.tbLogin_username.Text = username;

                    // Hide form login dan buka dashboard
                    this.Hide();
                    FormDasboard formDasboard1 = new FormDasboard(); // Kirim username ke dashboard
                    formDasboard1.Show();
                }
                else
                {
                    // Login gagal
                    MessageBox.Show("Username atau password salah.");
                }
            }

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            V_Forget v_forget = new V_Forget();
            v_forget.Show();
            this.Hide();
        }
    }
}
