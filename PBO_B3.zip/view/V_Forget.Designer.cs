﻿namespace PBO_PROJECT_B3.view
{
    partial class V_Forget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(V_Forget));
            panel1 = new Panel();
            pictureBox5 = new PictureBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            pictureBox4 = new PictureBox();
            tbreset_UsernameBaru = new TextBox();
            Lbreset = new Label();
            label2 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            btn_reset = new Button();
            tbreset_Password = new TextBox();
            tbreset_UsernameLama = new TextBox();
            label1 = new Label();
            close2 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(tbreset_UsernameBaru);
            panel1.Controls.Add(Lbreset);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btn_reset);
            panel1.Controls.Add(tbreset_Password);
            panel1.Controls.Add(tbreset_UsernameLama);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(46, 43);
            panel1.Name = "panel1";
            panel1.Size = new Size(597, 463);
            panel1.TabIndex = 0;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(145, 169);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(40, 40);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 23;
            pictureBox5.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(194, 156);
            label5.Name = "label5";
            label5.Size = new Size(118, 18);
            label5.TabIndex = 22;
            label5.Text = "Username Lama";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(194, 212);
            label4.Name = "label4";
            label4.Size = new Size(112, 18);
            label4.TabIndex = 21;
            label4.Text = "Username Baru";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(194, 268);
            label3.Name = "label3";
            label3.Size = new Size(110, 18);
            label3.TabIndex = 20;
            label3.Text = "Password Baru";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(145, 225);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(40, 40);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 19;
            pictureBox4.TabStop = false;
            // 
            // tbreset_UsernameBaru
            // 
            tbreset_UsernameBaru.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tbreset_UsernameBaru.Location = new Point(194, 235);
            tbreset_UsernameBaru.Name = "tbreset_UsernameBaru";
            tbreset_UsernameBaru.Size = new Size(257, 30);
            tbreset_UsernameBaru.TabIndex = 18;
            // 
            // Lbreset
            // 
            Lbreset.AutoSize = true;
            Lbreset.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            Lbreset.ForeColor = Color.DarkOliveGreen;
            Lbreset.Location = new Point(318, 389);
            Lbreset.Name = "Lbreset";
            Lbreset.Size = new Size(77, 18);
            Lbreset.TabIndex = 17;
            Lbreset.Text = "Click Here";
            Lbreset.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(220, 389);
            label2.Name = "label2";
            label2.Size = new Size(92, 18);
            label2.TabIndex = 16;
            label2.Text = "Login Again?";
            label2.Click += label2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(145, 281);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(40, 40);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 15;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(256, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // btn_reset
            // 
            btn_reset.BackColor = Color.DarkOliveGreen;
            btn_reset.Font = new Font("Arial Rounded MT Bold", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_reset.ForeColor = Color.White;
            btn_reset.Location = new Point(145, 338);
            btn_reset.Name = "btn_reset";
            btn_reset.Size = new Size(306, 48);
            btn_reset.TabIndex = 12;
            btn_reset.Text = "Reset";
            btn_reset.UseVisualStyleBackColor = false;
            btn_reset.Click += btn_reset_Click;
            // 
            // tbreset_Password
            // 
            tbreset_Password.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tbreset_Password.Location = new Point(194, 291);
            tbreset_Password.Name = "tbreset_Password";
            tbreset_Password.PasswordChar = '*';
            tbreset_Password.Size = new Size(257, 30);
            tbreset_Password.TabIndex = 11;
            // 
            // tbreset_UsernameLama
            // 
            tbreset_UsernameLama.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tbreset_UsernameLama.Location = new Point(194, 179);
            tbreset_UsernameLama.Name = "tbreset_UsernameLama";
            tbreset_UsernameLama.Size = new Size(257, 30);
            tbreset_UsernameLama.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(194, 106);
            label1.Name = "label1";
            label1.Size = new Size(211, 27);
            label1.TabIndex = 9;
            label1.Text = "RESET ACCOUNT";
            label1.Click += label1_Click;
            // 
            // close2
            // 
            close2.BackColor = Color.Red;
            close2.FlatAppearance.BorderColor = Color.Black;
            close2.FlatStyle = FlatStyle.Flat;
            close2.ForeColor = Color.White;
            close2.Location = new Point(625, 12);
            close2.Name = "close2";
            close2.Size = new Size(56, 25);
            close2.TabIndex = 2;
            close2.Text = "X";
            close2.UseVisualStyleBackColor = false;
            close2.Click += close2_Click;
            // 
            // V_Forget
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(693, 531);
            Controls.Add(close2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "V_Forget";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "V_Forget";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button close2;
        private Label Lbreset;
        private Label label2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private Button btn_reset;
        private TextBox tbreset_Password;
        private TextBox tbreset_UsernameLama;
        private Label label1;
        private PictureBox pictureBox4;
        private TextBox tbreset_UsernameBaru;
        private Label label4;
        private Label label3;
        private PictureBox pictureBox5;
        private Label label5;
    }
}